--
-- PostgreSQL database dump
--

-- Dumped from database version 9.5.14
-- Dumped by pg_dump version 10.5 (Ubuntu 10.5-0ubuntu0.18.04)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: aptitud; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.aptitud (
    id_aptitud integer NOT NULL,
    tipo character varying NOT NULL,
    nivel integer,
    id_usuario integer NOT NULL
);


ALTER TABLE public.aptitud OWNER TO postgres;

--
-- Name: aptitud_id_aptitud_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.aptitud_id_aptitud_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.aptitud_id_aptitud_seq OWNER TO postgres;

--
-- Name: aptitud_id_aptitud_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.aptitud_id_aptitud_seq OWNED BY public.aptitud.id_aptitud;


--
-- Name: carrera; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.carrera (
    id_carrera integer NOT NULL,
    nombre character varying NOT NULL,
    anios integer,
    cant_materias integer,
    id_dependencia integer NOT NULL,
    ordenanza character varying
);


ALTER TABLE public.carrera OWNER TO postgres;

--
-- Name: carrera_destinada; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.carrera_destinada (
    id_convocatoria integer NOT NULL,
    id_carrera integer NOT NULL,
    anios_necesario integer,
    cant_materias_nec integer
);


ALTER TABLE public.carrera_destinada OWNER TO postgres;

--
-- Name: carrera_id_carrera_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.carrera_id_carrera_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.carrera_id_carrera_seq OWNER TO postgres;

--
-- Name: carrera_id_carrera_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.carrera_id_carrera_seq OWNED BY public.carrera.id_carrera;


--
-- Name: convocatoria; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.convocatoria (
    id_convocatoria integer NOT NULL,
    titulo character varying NOT NULL,
    descripcion character varying,
    direccion character varying NOT NULL,
    fecha_alta timestamp without time zone NOT NULL,
    fecha_desde timestamp without time zone NOT NULL,
    fecha_hasta timestamp without time zone NOT NULL,
    cant_postulantes integer,
    activo boolean,
    id_tipo integer,
    id_sede_pedido integer,
    id_institucion integer NOT NULL,
    requisitos character varying
);


ALTER TABLE public.convocatoria OWNER TO postgres;

--
-- Name: convocatoria_id_convocatoria_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.convocatoria_id_convocatoria_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.convocatoria_id_convocatoria_seq OWNER TO postgres;

--
-- Name: convocatoria_id_convocatoria_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.convocatoria_id_convocatoria_seq OWNED BY public.convocatoria.id_convocatoria;


--
-- Name: dependencia; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.dependencia (
    id_dependencia integer NOT NULL,
    nombre character varying NOT NULL,
    sigla character varying NOT NULL
);


ALTER TABLE public.dependencia OWNER TO postgres;

--
-- Name: dependencia_id_dependencia_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.dependencia_id_dependencia_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.dependencia_id_dependencia_seq OWNER TO postgres;

--
-- Name: dependencia_id_dependencia_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.dependencia_id_dependencia_seq OWNED BY public.dependencia.id_dependencia;


--
-- Name: estado_postulante; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.estado_postulante (
    id_estado integer NOT NULL,
    nombre character varying NOT NULL
);


ALTER TABLE public.estado_postulante OWNER TO postgres;

--
-- Name: estado_postulante_id_estado_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.estado_postulante_id_estado_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.estado_postulante_id_estado_seq OWNER TO postgres;

--
-- Name: estado_postulante_id_estado_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.estado_postulante_id_estado_seq OWNED BY public.estado_postulante.id_estado;


--
-- Name: estudio; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.estudio (
    id_estudio integer NOT NULL,
    id_institucion integer NOT NULL,
    fecha_egreso timestamp without time zone,
    id_tipo integer,
    titulo character varying NOT NULL,
    id_usuario integer NOT NULL
);


ALTER TABLE public.estudio OWNER TO postgres;

--
-- Name: estudio_id_estudio_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.estudio_id_estudio_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.estudio_id_estudio_seq OWNER TO postgres;

--
-- Name: estudio_id_estudio_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.estudio_id_estudio_seq OWNED BY public.estudio.id_estudio;


--
-- Name: experiencia_laboral; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.experiencia_laboral (
    id_experiencia integer NOT NULL,
    id_usuario integer NOT NULL,
    titulo character varying NOT NULL,
    descripcion character varying
);


ALTER TABLE public.experiencia_laboral OWNER TO postgres;

--
-- Name: experiencia_laboral_id_experiencia_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.experiencia_laboral_id_experiencia_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.experiencia_laboral_id_experiencia_seq OWNER TO postgres;

--
-- Name: experiencia_laboral_id_experiencia_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.experiencia_laboral_id_experiencia_seq OWNED BY public.experiencia_laboral.id_experiencia;


--
-- Name: institucion; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.institucion (
    id_institucion integer NOT NULL,
    nombre character varying NOT NULL,
    email character varying NOT NULL,
    telefono character varying NOT NULL,
    direccion character varying
);


ALTER TABLE public.institucion OWNER TO postgres;

--
-- Name: institucion_id_institucion_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.institucion_id_institucion_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.institucion_id_institucion_seq OWNER TO postgres;

--
-- Name: institucion_id_institucion_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.institucion_id_institucion_seq OWNED BY public.institucion.id_institucion;


--
-- Name: localidad; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.localidad (
    id_localidad integer NOT NULL,
    nombre character varying NOT NULL,
    sigla character varying NOT NULL,
    cod_postal integer NOT NULL,
    caracteristica integer NOT NULL,
    id_provincia integer NOT NULL
);


ALTER TABLE public.localidad OWNER TO postgres;

--
-- Name: localidad_id_localidad_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.localidad_id_localidad_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.localidad_id_localidad_seq OWNER TO postgres;

--
-- Name: localidad_id_localidad_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.localidad_id_localidad_seq OWNED BY public.localidad.id_localidad;


--
-- Name: postulante; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.postulante (
    id_postulante integer NOT NULL,
    id_usuario integer NOT NULL,
    id_convocatoria integer NOT NULL,
    fecha_postulado timestamp without time zone NOT NULL,
    id_estado integer,
    orden_merito integer
);


ALTER TABLE public.postulante OWNER TO postgres;

--
-- Name: postulante_id_postulante_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.postulante_id_postulante_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.postulante_id_postulante_seq OWNER TO postgres;

--
-- Name: postulante_id_postulante_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.postulante_id_postulante_seq OWNED BY public.postulante.id_postulante;


--
-- Name: provincia; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.provincia (
    id_provincia integer NOT NULL,
    nombre character varying NOT NULL
);


ALTER TABLE public.provincia OWNER TO postgres;

--
-- Name: provincia_id_provincia_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.provincia_id_provincia_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.provincia_id_provincia_seq OWNER TO postgres;

--
-- Name: provincia_id_provincia_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.provincia_id_provincia_seq OWNED BY public.provincia.id_provincia;


--
-- Name: publicacion; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.publicacion (
    id_publicacion integer NOT NULL,
    titulo character varying NOT NULL,
    fecha timestamp without time zone,
    id_usuario integer NOT NULL
);


ALTER TABLE public.publicacion OWNER TO postgres;

--
-- Name: publicacion_id_publicacion_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.publicacion_id_publicacion_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.publicacion_id_publicacion_seq OWNER TO postgres;

--
-- Name: publicacion_id_publicacion_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.publicacion_id_publicacion_seq OWNED BY public.publicacion.id_publicacion;


--
-- Name: registro; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.registro (
    id_registro integer NOT NULL,
    usuario character varying NOT NULL,
    clave character varying NOT NULL,
    email character varying,
    fecha_registro timestamp without time zone NOT NULL,
    token character varying,
    recuperar_clave boolean,
    fecha_token timestamp without time zone
);


ALTER TABLE public.registro OWNER TO postgres;

--
-- Name: registro_id_registro_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.registro_id_registro_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.registro_id_registro_seq OWNER TO postgres;

--
-- Name: registro_id_registro_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.registro_id_registro_seq OWNED BY public.registro.id_registro;


--
-- Name: rendimiento_acad; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.rendimiento_acad (
    id_rendimiento integer NOT NULL,
    id_usuario integer NOT NULL,
    fecha_actualizado timestamp without time zone NOT NULL,
    cant_mat_aprobadas integer,
    anio_carrera integer,
    legajo character varying,
    fecha_egreso timestamp without time zone,
    id_carrera integer NOT NULL
);


ALTER TABLE public.rendimiento_acad OWNER TO postgres;

--
-- Name: rendimiento_acad_id_rendimiento_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.rendimiento_acad_id_rendimiento_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.rendimiento_acad_id_rendimiento_seq OWNER TO postgres;

--
-- Name: rendimiento_acad_id_rendimiento_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.rendimiento_acad_id_rendimiento_seq OWNED BY public.rendimiento_acad.id_rendimiento;


--
-- Name: rendimiento_no_acad; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.rendimiento_no_acad (
    id_rendimiento integer NOT NULL,
    id_usuario integer NOT NULL,
    fecha_actualizado timestamp without time zone NOT NULL,
    titulo character varying NOT NULL,
    descripcion character varying,
    observacion character varying,
    id_rol integer,
    horas_semanales integer,
    fecha_inicio timestamp without time zone,
    fecha_fin timestamp without time zone,
    norma_legal character varying NOT NULL,
    id_tipo integer
);


ALTER TABLE public.rendimiento_no_acad OWNER TO postgres;

--
-- Name: rendimiento_no_acad_id_rendimiento_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.rendimiento_no_acad_id_rendimiento_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.rendimiento_no_acad_id_rendimiento_seq OWNER TO postgres;

--
-- Name: rendimiento_no_acad_id_rendimiento_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.rendimiento_no_acad_id_rendimiento_seq OWNED BY public.rendimiento_no_acad.id_rendimiento;


--
-- Name: rol; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.rol (
    id_rol integer NOT NULL,
    nombre character varying NOT NULL
);


ALTER TABLE public.rol OWNER TO postgres;

--
-- Name: rol_id_rol_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.rol_id_rol_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.rol_id_rol_seq OWNER TO postgres;

--
-- Name: rol_id_rol_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.rol_id_rol_seq OWNED BY public.rol.id_rol;


--
-- Name: sede; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sede (
    id_sede integer NOT NULL,
    nombre character varying NOT NULL,
    id_dependencia integer NOT NULL,
    id_localidad integer NOT NULL
);


ALTER TABLE public.sede OWNER TO postgres;

--
-- Name: sede_id_sede_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.sede_id_sede_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.sede_id_sede_seq OWNER TO postgres;

--
-- Name: sede_id_sede_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.sede_id_sede_seq OWNED BY public.sede.id_sede;


--
-- Name: tipo; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tipo (
    id_tipo integer NOT NULL,
    nombre character varying NOT NULL
);


ALTER TABLE public.tipo OWNER TO postgres;

--
-- Name: tipo_id_tipo_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tipo_id_tipo_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tipo_id_tipo_seq OWNER TO postgres;

--
-- Name: tipo_id_tipo_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tipo_id_tipo_seq OWNED BY public.tipo.id_tipo;


--
-- Name: usuario; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.usuario (
    id_registro integer NOT NULL,
    dni character varying NOT NULL,
    telefono character varying,
    nombre character varying NOT NULL,
    apellido character varying NOT NULL,
    activo boolean,
    nacionalidad character varying NOT NULL,
    direccion character varying NOT NULL,
    id_localidad integer NOT NULL,
    fecha_nac timestamp without time zone NOT NULL,
    foto bytea,
    nombre_foto character varying,
    id_rol integer NOT NULL
);


ALTER TABLE public.usuario OWNER TO postgres;

--
-- Name: usuario_nombre_foto_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.usuario_nombre_foto_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.usuario_nombre_foto_seq OWNER TO postgres;

--
-- Name: usuario_nombre_foto_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.usuario_nombre_foto_seq OWNED BY public.usuario.nombre_foto;


--
-- Name: aptitud id_aptitud; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.aptitud ALTER COLUMN id_aptitud SET DEFAULT nextval('public.aptitud_id_aptitud_seq'::regclass);


--
-- Name: carrera id_carrera; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.carrera ALTER COLUMN id_carrera SET DEFAULT nextval('public.carrera_id_carrera_seq'::regclass);


--
-- Name: convocatoria id_convocatoria; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.convocatoria ALTER COLUMN id_convocatoria SET DEFAULT nextval('public.convocatoria_id_convocatoria_seq'::regclass);


--
-- Name: dependencia id_dependencia; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dependencia ALTER COLUMN id_dependencia SET DEFAULT nextval('public.dependencia_id_dependencia_seq'::regclass);


--
-- Name: estado_postulante id_estado; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.estado_postulante ALTER COLUMN id_estado SET DEFAULT nextval('public.estado_postulante_id_estado_seq'::regclass);


--
-- Name: estudio id_estudio; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.estudio ALTER COLUMN id_estudio SET DEFAULT nextval('public.estudio_id_estudio_seq'::regclass);


--
-- Name: experiencia_laboral id_experiencia; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.experiencia_laboral ALTER COLUMN id_experiencia SET DEFAULT nextval('public.experiencia_laboral_id_experiencia_seq'::regclass);


--
-- Name: institucion id_institucion; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.institucion ALTER COLUMN id_institucion SET DEFAULT nextval('public.institucion_id_institucion_seq'::regclass);


--
-- Name: localidad id_localidad; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.localidad ALTER COLUMN id_localidad SET DEFAULT nextval('public.localidad_id_localidad_seq'::regclass);


--
-- Name: postulante id_postulante; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.postulante ALTER COLUMN id_postulante SET DEFAULT nextval('public.postulante_id_postulante_seq'::regclass);


--
-- Name: provincia id_provincia; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.provincia ALTER COLUMN id_provincia SET DEFAULT nextval('public.provincia_id_provincia_seq'::regclass);


--
-- Name: publicacion id_publicacion; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.publicacion ALTER COLUMN id_publicacion SET DEFAULT nextval('public.publicacion_id_publicacion_seq'::regclass);


--
-- Name: registro id_registro; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.registro ALTER COLUMN id_registro SET DEFAULT nextval('public.registro_id_registro_seq'::regclass);


--
-- Name: rendimiento_acad id_rendimiento; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rendimiento_acad ALTER COLUMN id_rendimiento SET DEFAULT nextval('public.rendimiento_acad_id_rendimiento_seq'::regclass);


--
-- Name: rendimiento_no_acad id_rendimiento; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rendimiento_no_acad ALTER COLUMN id_rendimiento SET DEFAULT nextval('public.rendimiento_no_acad_id_rendimiento_seq'::regclass);


--
-- Name: rol id_rol; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rol ALTER COLUMN id_rol SET DEFAULT nextval('public.rol_id_rol_seq'::regclass);


--
-- Name: sede id_sede; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sede ALTER COLUMN id_sede SET DEFAULT nextval('public.sede_id_sede_seq'::regclass);


--
-- Name: tipo id_tipo; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tipo ALTER COLUMN id_tipo SET DEFAULT nextval('public.tipo_id_tipo_seq'::regclass);


--
-- Data for Name: aptitud; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: carrera; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.carrera VALUES (250, 'TÉCNICO UNIVERSITARIO FORESTAL', 3, NULL, 1, '390');
INSERT INTO public.carrera VALUES (251, 'TECNICATURA UNIVERSITARIA EN ESPACIOS VERDES', 3, NULL, 1, '442');
INSERT INTO public.carrera VALUES (252, 'TECNICATURA EN PLANTAS Y ANÁLISIS DE MENAS', 3, NULL, 6, NULL);
INSERT INTO public.carrera VALUES (253, 'TECNICATURA UNIVERSITARIA EN TOPOGRAFÍA', 3, NULL, 6, NULL);
INSERT INTO public.carrera VALUES (254, 'LICENCIATURA EN TECNOLOGÍA MINERA', 5, NULL, 6, '232/91, Mod. 912/01 y 216/09');
INSERT INTO public.carrera VALUES (255, 'TÉCNICO UNIVERSITARIO EN ACUICULTURA', 3, NULL, 7, NULL);
INSERT INTO public.carrera VALUES (256, 'PROFESORADO EN EDUCACIÓN FÍSICA', 4, NULL, 7, NULL);
INSERT INTO public.carrera VALUES (257, 'LICENCIATURA EN CIENCIAS BIOLÓGICAS', 5, NULL, 7, NULL);
INSERT INTO public.carrera VALUES (258, 'PROFESORADO EN CIENCIAS BIOLÓGICAS', 4, NULL, 7, NULL);
INSERT INTO public.carrera VALUES (259, 'DOCTORADO EN BIOLOGíA', 4, NULL, 7, '556/1986');
INSERT INTO public.carrera VALUES (260, 'LICENCIATURA EN HISTORIA', 5, NULL, 7, NULL);
INSERT INTO public.carrera VALUES (261, 'PROFESORADO UNIVERSITARIO EN CIENCIA POLÍTICA', 5, NULL, 8, NULL);
INSERT INTO public.carrera VALUES (262, 'ESPECIALIZACIóN EN FRUTOS SECOS', 1, NULL, 8, '1442/2014');
INSERT INTO public.carrera VALUES (263, 'LICENCIATURA EN GESTIÓN DE RECURSOS HUMANOS', 2, NULL, 8, NULL);
INSERT INTO public.carrera VALUES (264, 'PROFESORADO EN PSICOPEDAGOGIA', 5, NULL, 8, '431/09');
INSERT INTO public.carrera VALUES (265, 'TECNICATURA SUPERIOR EN PRODUCCIÓN AGROPECUARIA', 3, NULL, 8, NULL);
INSERT INTO public.carrera VALUES (266, 'TECNICATURA UNIVERSITARIA EN ADMINISTRACION PUBLICA', 3, NULL, 8, '1521/13');
INSERT INTO public.carrera VALUES (267, 'LICENCIATURA EN ADMINISTRACION PUBLICA', 4, NULL, 8, '814/01');
INSERT INTO public.carrera VALUES (268, 'LICENCIATURA EN CIENCIA POLITICA', 5, NULL, 8, '605/11');
INSERT INTO public.carrera VALUES (269, 'LICENCIATURA EN GESTION DE EMPRESAS AGROPECUARIAS', 5, NULL, 8, '374/11');
INSERT INTO public.carrera VALUES (270, 'PROFESORADO EN CIENCIAS AGROPECUARIAS', 5, NULL, 8, '995/12');
INSERT INTO public.carrera VALUES (271, 'PROFESORADO EN LENGUA Y COMUNICACION ORAL Y ESCRITA', 4, NULL, 8, '962/98');
INSERT INTO public.carrera VALUES (272, 'LICENCIATURA EN PSICOPEDAGOGIA', 5, NULL, 8, '432/09');
INSERT INTO public.carrera VALUES (273, 'LICENCIATURA EN BIOLOGÍA MARINA', 5, NULL, 9, '0062/08');
INSERT INTO public.carrera VALUES (274, 'TECNICATURA EN PRODUCCIÓN PESQUERA Y MARICULTURA', 2, NULL, 9, '298');
INSERT INTO public.carrera VALUES (275, 'LICENCIATURA EN ENFERMERIA', 5, NULL, 12, '0887/05');
INSERT INTO public.carrera VALUES (276, 'LICENCIATURA EN SANEAMIENTO Y PROTECCIÓN AMBIENTAL', 5, NULL, 12, NULL);
INSERT INTO public.carrera VALUES (277, 'LICENCIATURA EN HIGIENE Y SEGURIDAD EN EL TRABAJO (4TO Y 5TO CICLO)', 2, NULL, 12, NULL);
INSERT INTO public.carrera VALUES (278, 'INGENIERIA AGRONOMICA', 5, NULL, 10, '31');
INSERT INTO public.carrera VALUES (279, 'LICENCIATURA EN CIENCIAS DE LA EDUCACION', 5, NULL, 11, '139-434');
INSERT INTO public.carrera VALUES (280, 'DOCTORADO EN EDUCACIóN', 3, NULL, 11, '438/2009');
INSERT INTO public.carrera VALUES (281, 'PSICOLOGIA', 5, NULL, 11, '153-14');
INSERT INTO public.carrera VALUES (282, 'ESPECIALIZACIóN EN DIDáCTICA DE LAS CS. SOCIALES, CON MENCIóN EN HISTORIA, GEOGRAFíA Y EDUCACIóN', 2, NULL, 11, '639/2012');
INSERT INTO public.carrera VALUES (283, 'PROFESORADO EN NIVEL INICIAL', 3, NULL, 11, '886-1');
INSERT INTO public.carrera VALUES (284, 'PROFESORADO EN CIENCIAS DE LA EDUCACION', 5, NULL, 11, '239-403');
INSERT INTO public.carrera VALUES (285, 'PROFESORADO EN ENSEÑANZA PRIMARIA', 3, NULL, 11, '1016-391');
INSERT INTO public.carrera VALUES (286, 'PROFESORADO EN COMUNICACION SOCIAL', 4, NULL, 3, '173');
INSERT INTO public.carrera VALUES (287, 'MAESTRÍA EN SOCIOLOGÍA DE LA AGRICULTURA LATINOAMERICANA', 1, NULL, 3, '131/1998');
INSERT INTO public.carrera VALUES (288, 'ESPECIALIZACIóN EN TRABAJO SOCIAL FORENSE', 2, NULL, 3, '104/2010');
INSERT INTO public.carrera VALUES (289, 'ESPECIALIZACIóN EN DERECHO ADMINISTRATIVO', 1, NULL, 3, '394/2003');
INSERT INTO public.carrera VALUES (290, 'LICENCIATURA EN COMUNICACIÓN SOCIAL', 4, NULL, 3, NULL);
INSERT INTO public.carrera VALUES (291, 'ABOGACÍA', 5, NULL, 3, NULL);
INSERT INTO public.carrera VALUES (292, 'LICENCIATURA EN SERVICIO SOCIAL', 5, NULL, 3, NULL);
INSERT INTO public.carrera VALUES (293, 'LICENCIATURA EN SOCIOLOGIA', 5, NULL, 3, '150');
INSERT INTO public.carrera VALUES (294, 'LICENCIATURA EN MATEMÁTICA', 5, NULL, 15, '0187/98');
INSERT INTO public.carrera VALUES (295, 'MAESTRíA EN GESTIóN EMPRESARIA', 2, NULL, 15, '794/2012');
INSERT INTO public.carrera VALUES (296, 'MAESTRíA EN ECONOMíA Y POLíTICA ENERGéTICO AMBIENTAL', 2, NULL, 15, '220/1998');
INSERT INTO public.carrera VALUES (297, 'CONTADOR PÚBLICO NACIONAL', 5, NULL, 15, '088/85');
INSERT INTO public.carrera VALUES (298, 'CICLO GENERAL EN CIENCIAS ECONÓMICAS', NULL, NULL, 15, '0212/98');
INSERT INTO public.carrera VALUES (299, 'ESPECIALIZACIóN EN TRIBUTACIóN.', 2, NULL, 15, '760/97');
INSERT INTO public.carrera VALUES (300, 'PROFESORADO UNIVERSITARIO EN MATEMÁTICA', 4, NULL, 15, '1467/14');
INSERT INTO public.carrera VALUES (301, 'PROFESORADO EN CIENCIAS ECONÓMICAS', 4, NULL, 15, '999/2002');
INSERT INTO public.carrera VALUES (302, 'LICENCIATURA EN ADMINISTRACIÓN', 5, NULL, 15, '1033/05');
INSERT INTO public.carrera VALUES (303, 'MAESTRíA EN ESTUDIOS DE LAS MUJERES Y DE GéNERO', 2, NULL, 16, '144/2014');
INSERT INTO public.carrera VALUES (304, 'PROFESORADO EN HISTORIA', 5, NULL, 16, '96');
INSERT INTO public.carrera VALUES (305, 'PROFESORADO EN LETRAS', 4, NULL, 16, '572');
INSERT INTO public.carrera VALUES (306, 'PROFESORADO EN FILOSOFIA', 5, NULL, 16, '641');
INSERT INTO public.carrera VALUES (307, 'PROFESORADO EN GEOGRAFIA', 4, NULL, 16, '573');
INSERT INTO public.carrera VALUES (308, 'TECNICATURA EN PLANIFICACION AMBIENTAL', 2, NULL, 16, '500');
INSERT INTO public.carrera VALUES (309, 'LICENCIATURA EN GEOGRAFÍA', 5, NULL, 16, '573');
INSERT INTO public.carrera VALUES (310, 'LICENCIATURA EN HISTORIA', 5, NULL, 16, '96');
INSERT INTO public.carrera VALUES (311, 'LICENCIATURA EN LETRAS', 5, NULL, 16, '572');
INSERT INTO public.carrera VALUES (312, 'LICENCIATURA EN FILOSOFÍA', 5, NULL, 16, '641');
INSERT INTO public.carrera VALUES (313, 'DOCTORADO EN HISTORIA', 3, NULL, 16, '206/2015');
INSERT INTO public.carrera VALUES (314, 'TECNICATURA UNIVERSITARIA EN DESARROLLO WEB', 2, NULL, 17, '0312/09');
INSERT INTO public.carrera VALUES (315, 'PROFESORADO EN INFORMÁTICA', 4, NULL, 17, '1185/13');
INSERT INTO public.carrera VALUES (316, 'LICENCIATURA EN CIENCIAS DE LA COMPUTACIÓN', 5, NULL, 17, '1112/13');
INSERT INTO public.carrera VALUES (317, 'TECNICATURA UNIVERSITARIA EN ADMINISTRACIÓN DE SISTEMAS Y SOFTWARE LIBRE', 2, NULL, 17, '0895/12');
INSERT INTO public.carrera VALUES (318, 'LICENCIATURA EN SISTEMAS DE INFORMACIÓN', 5, NULL, 17, '1420/13');
INSERT INTO public.carrera VALUES (319, 'INGENIERÍA ELECTRÓNICA', 5, NULL, 2, '802/97');
INSERT INTO public.carrera VALUES (320, 'INGENIERÍA QUÍMICA', 5, NULL, 2, '803/97');
INSERT INTO public.carrera VALUES (321, 'INGENIERÍA EN PETRÓLEO', 5, NULL, 2, '804/97');
INSERT INTO public.carrera VALUES (322, 'MAESTRíA EN INTERVENCIóN AMBIENTAL', 2, NULL, 2, '794/2005');
INSERT INTO public.carrera VALUES (323, 'ESPECIALIZACIóN EN HIGIENE, SEGURIDAD Y MEDIO AMBIENTE EN LA CONSTRUCCIóN.', 2, NULL, 2, '1170/2006');
INSERT INTO public.carrera VALUES (324, 'DOCTORADO EN INGENIERíA', 5, NULL, 2, '1049/2013');
INSERT INTO public.carrera VALUES (325, 'INGENIERÍA MECÁNICA', 5, NULL, 2, '806/97');
INSERT INTO public.carrera VALUES (326, 'INGENIERÍA CIVIL', 5, NULL, 2, '805/97');
INSERT INTO public.carrera VALUES (327, 'DOCTORADO EN ENSEñANZA DE CIENCIAS EXACTAS Y NATURALES', 4, NULL, 2, '078/2010');
INSERT INTO public.carrera VALUES (328, 'PROFESORADO EN QUIMICA', 4, NULL, 2, '1001');
INSERT INTO public.carrera VALUES (329, 'LICENCIATURA EN CIENCIAS GEOLÓGICAS', 5, NULL, 2, '443/09');
INSERT INTO public.carrera VALUES (330, 'INGENIERÍA ELÉCTRICA', 5, NULL, 2, '807/97');
INSERT INTO public.carrera VALUES (331, 'PROFESORADO EN FÍSICA', 3, NULL, 2, '1002/98');
INSERT INTO public.carrera VALUES (332, 'TRADUCTORADO PÚBLICO EN IDIOMA INGLÉS', 5, NULL, 5, NULL);
INSERT INTO public.carrera VALUES (333, 'MAESTRíA EN LINGüíSTICA APLICADA', 3, NULL, 5, 'POSGRADO');
INSERT INTO public.carrera VALUES (334, 'LA MAESTRíA EN LINGüíSTICA APLICADA CON ORIENTACIóN ENSEñANZA DE LENGUAS EXTRANJERAS', 3, NULL, 5, 'POSGRADO');
INSERT INTO public.carrera VALUES (335, 'MAESTRíA EN LINGüíSTICA', 2, NULL, 5, '0956/93');
INSERT INTO public.carrera VALUES (336, 'ESPECIALIZACIóN EN LINGüíSTICA APLICADA CON ORIENTACIóN ENSEñANZA DE LENGUAS EXTRANJERAS', 1, NULL, 5, '787/2012');
INSERT INTO public.carrera VALUES (337, 'MAESTRíA EN LINGüíSTICA APLICADA A LA ENSEñANZA DE LAS LENGUAS EXTRANJERAS', 2, NULL, 5, '789/2012');
INSERT INTO public.carrera VALUES (338, 'PROFESORADO EN INGLES', 5, NULL, 5, '430');
INSERT INTO public.carrera VALUES (339, 'MEDICINA', 7, NULL, 13, '1047/13');
INSERT INTO public.carrera VALUES (340, 'TECNICATURA EN CONTROL E HIGIENE DE LOS ALIMENTOS', 3, NULL, 14, '550');
INSERT INTO public.carrera VALUES (341, 'ESPECIALIZACIóN EN CALIDAD E INOCUIDAD DE ALIMENTOS', 1, NULL, 14, '698/2010');
INSERT INTO public.carrera VALUES (342, 'LICENCIATURA EN GERENCIAMIENTO GASTRONOMICO', 4, NULL, 14, '0553/2011');
INSERT INTO public.carrera VALUES (343, 'LICENCIATURA EN TECNOLOGIA DE LOS ALIMENTOS', 5, NULL, 14, '238');
INSERT INTO public.carrera VALUES (344, 'ESPECIALIZACIóN EN MARKETING DE SERVICIOS', 1, NULL, 4, '303/2011');
INSERT INTO public.carrera VALUES (345, 'LICENCIATURA EN TURISMO', 5, NULL, 4, '624/96');
INSERT INTO public.carrera VALUES (346, 'GUÍA UNIVERSITARIO EN TURISMO', 2, NULL, 4, '1062/06');
INSERT INTO public.carrera VALUES (347, 'TECNICATURA EN EMPRESAS DE SERVICIOS TURÍSTICOS', 2, NULL, 4, '800/05');
INSERT INTO public.carrera VALUES (348, 'MAESTRíA EN MARKETING DE SERVICIOS', 2, NULL, 4, '705/2010');


--
-- Data for Name: carrera_destinada; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: convocatoria; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: dependencia; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.dependencia VALUES (1, 'Asentamiento Universitario San Martín de los Andes', 'ASMA');
INSERT INTO public.dependencia VALUES (2, 'Facultad de Ingeniería', 'FAIN');
INSERT INTO public.dependencia VALUES (3, 'Facultad de Derecho y Ciencias Sociales', 'FADE');
INSERT INTO public.dependencia VALUES (4, 'Facultad de Turismo', 'FATU');
INSERT INTO public.dependencia VALUES (5, 'Facultad de Lenguas', 'FALE');
INSERT INTO public.dependencia VALUES (6, 'Asentamiento Universitario Zapala', 'AUZA');
INSERT INTO public.dependencia VALUES (7, 'Centro Regional Universitario Bariloche', 'CRUB');
INSERT INTO public.dependencia VALUES (8, 'Centro Universitario Regional Zona Atlántica', 'CUZA');
INSERT INTO public.dependencia VALUES (9, 'Escuela Superior de Ciencias Marinas', 'ESCM');
INSERT INTO public.dependencia VALUES (10, 'Facultad de Ciencias Agrarias', 'FACA');
INSERT INTO public.dependencia VALUES (11, 'Facultad de Ciencias de la Educación', 'FACE');
INSERT INTO public.dependencia VALUES (12, 'Facultad de Ciencias del Ambiente y la Salud', 'FAAS');
INSERT INTO public.dependencia VALUES (13, 'Facultad de Ciencias Médicas', 'FAME');
INSERT INTO public.dependencia VALUES (14, 'Facultad de Ciencias y Tecnologías de los Alimentos', 'FATA');
INSERT INTO public.dependencia VALUES (15, 'Facultad de Economía y Administración', 'FAEA');
INSERT INTO public.dependencia VALUES (16, 'Facultad de Humanidades', 'FAHU');
INSERT INTO public.dependencia VALUES (17, 'Facultad de Informática', 'FAIF');
INSERT INTO public.dependencia VALUES (18, 'Administración Central', 'ADCE');


--
-- Data for Name: estado_postulante; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: estudio; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: experiencia_laboral; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: institucion; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: localidad; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.localidad VALUES (1, 'Cinco Saltos', 'CSA', 8303, 299, 1);
INSERT INTO public.localidad VALUES (2, 'Cipolletti', 'CIP', 8324, 299, 1);
INSERT INTO public.localidad VALUES (3, 'General Roca', 'GRO', 8332, 298, 1);
INSERT INTO public.localidad VALUES (4, 'Neuquén Capital', 'NQN', 8300, 299, 2);
INSERT INTO public.localidad VALUES (5, 'San Carlos de Bariloche', 'BHE', 8400, 294, 1);
INSERT INTO public.localidad VALUES (6, 'Viedma', 'VIE', 8500, 2920, 1);
INSERT INTO public.localidad VALUES (7, 'San Antonio Oeste', 'SAO', 8520, 2934, 1);
INSERT INTO public.localidad VALUES (8, 'San Martín de los Andes', 'SMA', 8370, 294, 2);
INSERT INTO public.localidad VALUES (9, 'Zapala', 'ZAP', 8340, 2942, 2);
INSERT INTO public.localidad VALUES (10, 'Villa Regina', 'VRE', 8336, 298, 1);
INSERT INTO public.localidad VALUES (11, 'Allen', 'ALL', 8328, 298, 1);
INSERT INTO public.localidad VALUES (13, 'Esquel', 'ESQ', 9200, 2945, 3);
INSERT INTO public.localidad VALUES (12, 'Choele Choel', 'CHC', 8360, 2946, 1);
INSERT INTO public.localidad VALUES (14, 'Trelew', 'TRW', 9100, 298, 3);
INSERT INTO public.localidad VALUES (15, 'Puerto Madryn', 'PMA', 9120, 298, 3);
INSERT INTO public.localidad VALUES (16, 'Chos Malal', 'CHM', 8353, 2948, 2);


--
-- Data for Name: postulante; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: provincia; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.provincia VALUES (1, 'Río Negro');
INSERT INTO public.provincia VALUES (2, 'Neuquén');
INSERT INTO public.provincia VALUES (3, 'Chubut');


--
-- Data for Name: publicacion; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: registro; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: rendimiento_acad; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: rendimiento_no_acad; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: rol; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: sede; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.sede VALUES (20, 'Güemes y Einstein', 12, 11);
INSERT INTO public.sede VALUES (21, 'Pacheco 460 - Edificio Pto. Moreno', 12, 12);
INSERT INTO public.sede VALUES (22, '9 de Julio 102', 12, 13);
INSERT INTO public.sede VALUES (23, 'Avda. Roca 743', 12, 15);
INSERT INTO public.sede VALUES (24, 'Pasaje de la Paz 235', 1, 8);
INSERT INTO public.sede VALUES (25, 'Av. 12 de julio y Rahue', 6, 9);
INSERT INTO public.sede VALUES (26, 'Quintral S/N Barrio Jardín Botánico', 7, 5);
INSERT INTO public.sede VALUES (27, 'Monseñor Esandi y Ayacucho', 8, 6);
INSERT INTO public.sede VALUES (28, 'San Martín 247', 9, 7);
INSERT INTO public.sede VALUES (29, 'Ruta 151 Km 12,5', 10, 1);
INSERT INTO public.sede VALUES (30, 'Yrigoyen 2000', 11, 2);
INSERT INTO public.sede VALUES (31, 'Buenos Aires 1400', 12, 4);
INSERT INTO public.sede VALUES (32, 'Av. Luis Toschi y Los Arrayanes', 13, 2);
INSERT INTO public.sede VALUES (33, '25 de Mayo y Reconquista', 14, 10);
INSERT INTO public.sede VALUES (34, 'Mendoza y Perú', 3, 3);
INSERT INTO public.sede VALUES (35, 'Buenos Aires 1400', 3, 4);
INSERT INTO public.sede VALUES (36, 'Buenos Aires 1400', 15, 4);
INSERT INTO public.sede VALUES (37, 'Buenos Aires 1400', 16, 4);
INSERT INTO public.sede VALUES (38, 'Buenos Aires 1400', 17, 4);
INSERT INTO public.sede VALUES (39, 'Buenos Aires 1400', 2, 4);
INSERT INTO public.sede VALUES (40, 'Buenos Aires 1400', 4, 4);
INSERT INTO public.sede VALUES (41, 'Mendoza y Perú', 5, 3);
INSERT INTO public.sede VALUES (42, 'La Madrid 152', 2, 16);


--
-- Data for Name: tipo; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.tipo VALUES (2, 'Curso');
INSERT INTO public.tipo VALUES (3, 'Evento');
INSERT INTO public.tipo VALUES (4, 'Bolsa de Trabajo');
INSERT INTO public.tipo VALUES (5, 'Proyecto de Investigación');
INSERT INTO public.tipo VALUES (6, 'Proyecto de Extensión');
INSERT INTO public.tipo VALUES (7, 'Posgrado');
INSERT INTO public.tipo VALUES (1, 'Pasantia');


--
-- Data for Name: usuario; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Name: aptitud_id_aptitud_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.aptitud_id_aptitud_seq', 1, false);


--
-- Name: carrera_id_carrera_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.carrera_id_carrera_seq', 348, true);


--
-- Name: convocatoria_id_convocatoria_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.convocatoria_id_convocatoria_seq', 1, false);


--
-- Name: dependencia_id_dependencia_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.dependencia_id_dependencia_seq', 18, true);


--
-- Name: estado_postulante_id_estado_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.estado_postulante_id_estado_seq', 1, false);


--
-- Name: estudio_id_estudio_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.estudio_id_estudio_seq', 1, false);


--
-- Name: experiencia_laboral_id_experiencia_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.experiencia_laboral_id_experiencia_seq', 1, false);


--
-- Name: institucion_id_institucion_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.institucion_id_institucion_seq', 1, false);


--
-- Name: localidad_id_localidad_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.localidad_id_localidad_seq', 1, false);


--
-- Name: postulante_id_postulante_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.postulante_id_postulante_seq', 1, false);


--
-- Name: provincia_id_provincia_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.provincia_id_provincia_seq', 1, false);


--
-- Name: publicacion_id_publicacion_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.publicacion_id_publicacion_seq', 1, false);


--
-- Name: registro_id_registro_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.registro_id_registro_seq', 1, false);


--
-- Name: rendimiento_acad_id_rendimiento_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.rendimiento_acad_id_rendimiento_seq', 1, false);


--
-- Name: rendimiento_no_acad_id_rendimiento_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.rendimiento_no_acad_id_rendimiento_seq', 1, false);


--
-- Name: rol_id_rol_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.rol_id_rol_seq', 1, false);


--
-- Name: sede_id_sede_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.sede_id_sede_seq', 42, true);


--
-- Name: tipo_id_tipo_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tipo_id_tipo_seq', 7, true);


--
-- Name: usuario_nombre_foto_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.usuario_nombre_foto_seq', 1, false);


--
-- Name: aptitud aptitud_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.aptitud
    ADD CONSTRAINT aptitud_pkey PRIMARY KEY (id_aptitud);


--
-- Name: carrera_destinada carrera_destinada_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.carrera_destinada
    ADD CONSTRAINT carrera_destinada_pkey PRIMARY KEY (id_convocatoria, id_carrera);


--
-- Name: carrera carrera_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.carrera
    ADD CONSTRAINT carrera_pkey PRIMARY KEY (id_carrera);


--
-- Name: convocatoria convocatoria_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.convocatoria
    ADD CONSTRAINT convocatoria_pkey PRIMARY KEY (id_convocatoria);


--
-- Name: dependencia dependencia_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dependencia
    ADD CONSTRAINT dependencia_pkey PRIMARY KEY (id_dependencia);


--
-- Name: estado_postulante estado_postulante_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.estado_postulante
    ADD CONSTRAINT estado_postulante_pkey PRIMARY KEY (id_estado);


--
-- Name: estudio estudio_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.estudio
    ADD CONSTRAINT estudio_pkey PRIMARY KEY (id_estudio);


--
-- Name: experiencia_laboral experiencia_laboral_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.experiencia_laboral
    ADD CONSTRAINT experiencia_laboral_pkey PRIMARY KEY (id_experiencia);


--
-- Name: institucion institucion_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.institucion
    ADD CONSTRAINT institucion_pkey PRIMARY KEY (id_institucion);


--
-- Name: localidad localidad_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.localidad
    ADD CONSTRAINT localidad_pkey PRIMARY KEY (id_localidad);


--
-- Name: postulante postulante_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.postulante
    ADD CONSTRAINT postulante_pkey PRIMARY KEY (id_postulante);


--
-- Name: provincia provincia_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.provincia
    ADD CONSTRAINT provincia_pkey PRIMARY KEY (id_provincia);


--
-- Name: publicacion publicacion_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.publicacion
    ADD CONSTRAINT publicacion_pkey PRIMARY KEY (id_publicacion);


--
-- Name: registro registro_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.registro
    ADD CONSTRAINT registro_pkey PRIMARY KEY (id_registro);


--
-- Name: rendimiento_acad rendimiento_acad_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rendimiento_acad
    ADD CONSTRAINT rendimiento_acad_pkey PRIMARY KEY (id_rendimiento);


--
-- Name: rendimiento_no_acad rendimiento_no_acad_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rendimiento_no_acad
    ADD CONSTRAINT rendimiento_no_acad_pkey PRIMARY KEY (id_rendimiento);


--
-- Name: rol rol_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rol
    ADD CONSTRAINT rol_pkey PRIMARY KEY (id_rol);


--
-- Name: sede sede_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sede
    ADD CONSTRAINT sede_pkey PRIMARY KEY (id_sede);


--
-- Name: tipo tipo_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tipo
    ADD CONSTRAINT tipo_pkey PRIMARY KEY (id_tipo);


--
-- Name: usuario usuario_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.usuario
    ADD CONSTRAINT usuario_pkey PRIMARY KEY (id_registro);


--
-- Name: aptitud fk_aptitud_usuario; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.aptitud
    ADD CONSTRAINT fk_aptitud_usuario FOREIGN KEY (id_usuario) REFERENCES public.usuario(id_registro);


--
-- Name: carrera fk_carrera_dependencia; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.carrera
    ADD CONSTRAINT fk_carrera_dependencia FOREIGN KEY (id_dependencia) REFERENCES public.dependencia(id_dependencia);


--
-- Name: carrera_destinada fk_carrera_destinada_carrera; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.carrera_destinada
    ADD CONSTRAINT fk_carrera_destinada_carrera FOREIGN KEY (id_carrera) REFERENCES public.carrera(id_carrera);


--
-- Name: carrera_destinada fk_carrera_destinada_convocatoria; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.carrera_destinada
    ADD CONSTRAINT fk_carrera_destinada_convocatoria FOREIGN KEY (id_convocatoria) REFERENCES public.convocatoria(id_convocatoria);


--
-- Name: convocatoria fk_convocatoria_institucion; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.convocatoria
    ADD CONSTRAINT fk_convocatoria_institucion FOREIGN KEY (id_institucion) REFERENCES public.institucion(id_institucion);


--
-- Name: convocatoria fk_convocatoria_sede; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.convocatoria
    ADD CONSTRAINT fk_convocatoria_sede FOREIGN KEY (id_sede_pedido) REFERENCES public.sede(id_sede);


--
-- Name: convocatoria fk_convocatoria_tipo; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.convocatoria
    ADD CONSTRAINT fk_convocatoria_tipo FOREIGN KEY (id_tipo) REFERENCES public.tipo(id_tipo);


--
-- Name: estudio fk_estudio_institucion; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.estudio
    ADD CONSTRAINT fk_estudio_institucion FOREIGN KEY (id_institucion) REFERENCES public.institucion(id_institucion);


--
-- Name: estudio fk_estudio_usuario; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.estudio
    ADD CONSTRAINT fk_estudio_usuario FOREIGN KEY (id_usuario) REFERENCES public.usuario(id_registro);


--
-- Name: experiencia_laboral fk_experiencia_laboral_usuario; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.experiencia_laboral
    ADD CONSTRAINT fk_experiencia_laboral_usuario FOREIGN KEY (id_usuario) REFERENCES public.usuario(id_registro);


--
-- Name: postulante fk_postulante_convocatoria; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.postulante
    ADD CONSTRAINT fk_postulante_convocatoria FOREIGN KEY (id_convocatoria) REFERENCES public.convocatoria(id_convocatoria);


--
-- Name: postulante fk_postulante_estado_postulante; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.postulante
    ADD CONSTRAINT fk_postulante_estado_postulante FOREIGN KEY (id_estado) REFERENCES public.estado_postulante(id_estado);


--
-- Name: postulante fk_postulante_usuario; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.postulante
    ADD CONSTRAINT fk_postulante_usuario FOREIGN KEY (id_usuario) REFERENCES public.usuario(id_registro);


--
-- Name: publicacion fk_publicacion_usuario; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.publicacion
    ADD CONSTRAINT fk_publicacion_usuario FOREIGN KEY (id_usuario) REFERENCES public.usuario(id_registro);


--
-- Name: rendimiento_acad fk_rendimiento_acad_carrera; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rendimiento_acad
    ADD CONSTRAINT fk_rendimiento_acad_carrera FOREIGN KEY (id_carrera) REFERENCES public.carrera(id_carrera);


--
-- Name: rendimiento_acad fk_rendimiento_acad_usuario; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rendimiento_acad
    ADD CONSTRAINT fk_rendimiento_acad_usuario FOREIGN KEY (id_usuario) REFERENCES public.usuario(id_registro);


--
-- Name: rendimiento_no_acad fk_rendimiento_no_acad_rol; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rendimiento_no_acad
    ADD CONSTRAINT fk_rendimiento_no_acad_rol FOREIGN KEY (id_rol) REFERENCES public.rol(id_rol);


--
-- Name: rendimiento_no_acad fk_rendimiento_no_acad_tipo; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rendimiento_no_acad
    ADD CONSTRAINT fk_rendimiento_no_acad_tipo FOREIGN KEY (id_tipo) REFERENCES public.tipo(id_tipo);


--
-- Name: rendimiento_no_acad fk_rendimiento_no_acad_usuario; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rendimiento_no_acad
    ADD CONSTRAINT fk_rendimiento_no_acad_usuario FOREIGN KEY (id_usuario) REFERENCES public.usuario(id_registro);


--
-- Name: sede fk_sede_dependencia; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sede
    ADD CONSTRAINT fk_sede_dependencia FOREIGN KEY (id_dependencia) REFERENCES public.dependencia(id_dependencia);


--
-- Name: sede fk_sede_localidad; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sede
    ADD CONSTRAINT fk_sede_localidad FOREIGN KEY (id_localidad) REFERENCES public.localidad(id_localidad);


--
-- Name: usuario fk_usuario_localidad; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.usuario
    ADD CONSTRAINT fk_usuario_localidad FOREIGN KEY (id_localidad) REFERENCES public.localidad(id_localidad);


--
-- Name: usuario fk_usuario_registro; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.usuario
    ADD CONSTRAINT fk_usuario_registro FOREIGN KEY (id_registro) REFERENCES public.registro(id_registro);


--
-- Name: usuario fk_usuario_rol; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.usuario
    ADD CONSTRAINT fk_usuario_rol FOREIGN KEY (id_rol) REFERENCES public.rol(id_rol);


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

